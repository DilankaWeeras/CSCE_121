#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void removeDumb(char word[]);
void removeSpace(char word[]);
bool isPalindromeR(char word[]);
bool isPalindrome(char word[], bool space, bool punct);
void printUsageInfo(char commandString[]);
#endif